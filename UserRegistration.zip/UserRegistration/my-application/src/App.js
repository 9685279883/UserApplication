// import logo from './logo.svg';
import React from 'react';
import './App.css';
import {Login} from './Components/Login'
import {Register} from './Components/Register'
import { useState } from 'react';

function App() {
  const [ currentForm, setCurrentForm] = useState('login');
  const toggleKey = ( formName) => {
    setCurrentForm(formName);
  }
  return (
    <div className="App">
    {
      currentForm === "login" ? <Login onClick={toggleKey}/>: <Register onClick={toggleKey}/>
    }
      
    </div>
  );
}

export default App;
