import React from "react"
import { useState } from "react";

export const Login = (props) =>{

    const [email, setEmail] = useState('');
    const [pass, setPass] = useState('');

    const handleSubmit = (e)=>{
        e.preventDefault();
        console.log(email);
    }


    return(
        <div className="wrappar">
            <h1 className="heading">User Registration Web Application</h1>
            <form className="allform" onSubmit={handleSubmit}>
            <label htmlFor="email">Email:</label>
            <input type="email" placeholder="Enter Your Email"
            id="email" name="email" value={email} onChange={(e)=> setEmail(e.target.value)}></input>
            
            <label htmlFor="password">Password:</label>
            <input type="password" placeholder="Enter Your Password"
            id="password" name="password" value={pass} onChange={(e)=> setPass(e.target.value)}></input>

            <button className="btn" type="submit">Login</button>
        </form>

        <button className="linkbtn" onClick={()=> props.onClick('register')}>You don't have an account, Register to create an account...</button>
        </div>
    )
}

// export default Login;

