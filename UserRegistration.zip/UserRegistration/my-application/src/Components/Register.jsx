import React from "react"
import { useState } from "react";


export const Register = (props) =>{
    const [ email, setEmail] = useState('');
    const [pass, setPass] = useState('');
    const [ name, setName] = useState('');

    const handleSubmit = (e)=>{
        e.preventDefault();
        console.log(email);
    }


    return(
        <div className="wrappar">
            <form className='allform' onSubmit={handleSubmit}>
            <label htmlFor="name">Full Name</label>
            <input value={name} onChange={(e)=> setName(e.target.value)} name="name" 
            id="name" placeholder="Full Name"></input>


            <label htmlFor="email">Email:</label>
            <input type="email" placeholder="Enter Your Email"
            id="email" name="email" value={email} onChange={(e)=> setEmail(e.target.value)}></input>
            
            <label htmlFor="password">Password:</label>
            <input type="password" placeholder="Enter Your Password"
            id="password" name="password" value={pass} onChange={(e)=> setPass(e.target.value)}></input>

            <button className="btnReg" type="submit">Register</button>
        </form>

        <button className="linkbtn" onClick={()=> props.onClick('login')}>You have allready an account, Login here...</button>
        </div>
    )
}

// export default Register;

