

const express = require("express");
const router = express.Router();

const { login, register} = require("../controller/application");

router.post("/login", login);
router.post("/register", register);


//protected Route
router.get("/student", isStudent, (req, res)=>{
    res.json({
        success:true,
        message:"wellcome to the protected route for students"
    });
});

router.get("/admin", isAdmin, (req, res)=>{
    res.json({
        success:true,
        message:"wellcome to the protected route for Admin"
    });
})

module.exports = router;


